<html><head><tittle></tittle></head></html>
<body>
  <h1>Hello world</h1>
  <?php
  
  ?>
</body>