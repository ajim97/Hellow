const textArea = document.getElementById('textArea');
const undoBtn = document.getElementById('undoBtn');
const redoBtn = document.getElementById('redoBtn');

let undoStack = [];
let redoStack = [];

textArea.addEventListener('input', () => {
    undoStack.push(textArea.value);
    redoStack = [];
});

undoBtn.addEventListener('click', () => {
    if (undoStack.length > 0) {
        redoStack.push(textArea.value);
        const lastValue = undoStack.pop();
        textArea.value = lastValue;
    }
});

redoBtn.addEventListener('click', () => {
    if (redoStack.length > 0) {
        undoStack.push(textArea.value);
        const redoValue = redoStack.pop();
        textArea.value = redoValue;
    }
});
